
export type StorageItemType = 'note' | 'page';

export interface StorageItem {
  id: string;
  title: string;
  content: string;
  type: StorageItemType;
  createdAt: number;
}

export interface UserProfile {
  name: string;
  faceData: string; // Base64 biometric baseline
  registeredAt: number;
  storage: StorageItem[];
}

export interface VerificationResult {
  match: boolean;
  confidence: number;
  reasoning: string;
}

export enum AuthStep {
  LANDING = 'LANDING',
  REGISTER_NAME = 'REGISTER_NAME',
  REGISTER_FACE = 'REGISTER_FACE',
  LOGIN_FACE = 'LOGIN_FACE',
  DASHBOARD = 'DASHBOARD',
  VIEWER = 'VIEWER'
}
