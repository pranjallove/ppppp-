
import { GoogleGenAI, Type } from "@google/genai";
import { VerificationResult } from "../types";

const MODEL_NAME = 'gemini-3-flash-preview';

export const verifyFace = async (
  registeredBase64: string,
  attemptBase64: string
): Promise<VerificationResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

  // Clean base64 strings (remove prefix if present)
  const cleanReg = registeredBase64.replace(/^data:image\/\w+;base64,/, "");
  const cleanAttempt = attemptBase64.replace(/^data:image\/\w+;base64,/, "");

  const prompt = `
    Compare the person in these two images. 
    Image 1 is the registered user. 
    Image 2 is the current login attempt.
    
    Determine if they are the same person. Ignore changes in lighting, background, clothing, or slight facial expression changes.
    Be strict but fair. If the person looks significantly different or it is a different person, set match to false.
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: cleanReg,
            },
          },
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: cleanAttempt,
            },
          },
          { text: prompt },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            match: {
              type: Type.BOOLEAN,
              description: 'True if both images show the same person.',
            },
            confidence: {
              type: Type.NUMBER,
              description: 'Confidence score between 0 and 1.',
            },
            reasoning: {
              type: Type.STRING,
              description: 'A brief explanation of the decision.',
            },
          },
          required: ["match", "confidence", "reasoning"],
        },
      },
    });

    const resultStr = response.text.trim();
    return JSON.parse(resultStr) as VerificationResult;
  } catch (error) {
    console.error("Gemini Verification Error:", error);
    throw new Error("Failed to verify face. Please try again.");
  }
};
