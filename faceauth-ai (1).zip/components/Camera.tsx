
import React, { useRef, useEffect, useState, useCallback } from 'react';

interface CameraProps {
  onCapture: (base64: string) => void;
  isProcessing: boolean;
  label?: string;
}

const Camera: React.FC<CameraProps> = ({ onCapture, isProcessing, label }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);

  const startCamera = useCallback(async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: 'user',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      setError("Unable to access camera. Please check permissions.");
      console.error(err);
    }
  }, []);

  useEffect(() => {
    startCamera();
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [startCamera]);

  const capture = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvasRef.current.toDataURL('image/jpeg', 0.8);
        onCapture(dataUrl);
      }
    }
  };

  return (
    <div className="flex flex-col items-center w-full max-w-md mx-auto">
      <div className="relative w-full aspect-video bg-black rounded-2xl overflow-hidden border-4 border-gray-800 shadow-2xl">
        {error ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center text-red-400">
            <i className="fas fa-exclamation-triangle text-4xl mb-4"></i>
            <p>{error}</p>
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover mirror"
              style={{ transform: 'scaleX(-1)' }}
            />
            {/* Scanning Effect */}
            {!isProcessing && <div className="scan-line"></div>}
            
            {/* Loading Overlay */}
            {isProcessing && (
              <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center z-10">
                <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                <p className="text-blue-400 font-medium animate-pulse">Analyzing Biometrics...</p>
              </div>
            )}
            
            {/* Guide Overlay */}
            <div className="absolute inset-0 border-[40px] border-black/30 pointer-events-none flex items-center justify-center">
                <div className="w-48 h-64 border-2 border-white/50 rounded-[50%] opacity-40"></div>
            </div>
          </>
        )}
      </div>

      <canvas ref={canvasRef} className="hidden" />

      <div className="mt-8 flex flex-col items-center gap-4">
        <button
          onClick={capture}
          disabled={isProcessing || !!error}
          className={`px-8 py-4 rounded-full font-bold text-lg transition-all transform active:scale-95 flex items-center gap-3
            ${isProcessing || !!error 
              ? 'bg-gray-700 text-gray-400 cursor-not-allowed' 
              : 'bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_20px_rgba(37,99,235,0.4)] hover:shadow-[0_0_30px_rgba(37,99,235,0.6)]'
            }`}
        >
          <i className={`fas ${isProcessing ? 'fa-circle-notch fa-spin' : 'fa-camera'}`}></i>
          {label || 'Capture Image'}
        </button>
        <p className="text-gray-500 text-sm">Center your face within the frame</p>
      </div>
    </div>
  );
};

export default Camera;
