
import React, { useState, useEffect } from 'react';
import { AuthStep, UserProfile, VerificationResult, StorageItem, StorageItemType } from './types';
import Camera from './components/Camera';
import { verifyFace } from './services/geminiService';

const App: React.FC = () => {
  const [step, setStep] = useState<AuthStep>(AuthStep.LANDING);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [tempName, setTempName] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [lastResult, setLastResult] = useState<VerificationResult | null>(null);

  // Storage UI state
  const [entryTitle, setEntryTitle] = useState('');
  const [entryContent, setEntryContent] = useState('');
  const [entryType, setEntryType] = useState<StorageItemType>('page');
  const [isAddingEntry, setIsAddingEntry] = useState(false);
  const [viewingItem, setViewingItem] = useState<StorageItem | null>(null);

  // Load from local storage on mount
  useEffect(() => {
    const savedData = localStorage.getItem('facevault_user_data');
    if (savedData) {
      try {
        setUser(JSON.parse(savedData));
      } catch (e) {
        console.error("Failed to parse local storage", e);
      }
    }
  }, []);

  // Save to local storage whenever user state changes
  useEffect(() => {
    if (user) {
      localStorage.setItem('facevault_user_data', JSON.stringify(user));
    }
  }, [user]);

  const handleRegisterFace = (base64: string) => {
    setIsProcessing(true);
    setAuthError(null);
    
    setTimeout(() => {
      const newUser: UserProfile = {
        name: tempName,
        faceData: base64,
        registeredAt: Date.now(),
        storage: []
      };
      setUser(newUser);
      setIsProcessing(false);
      setStep(AuthStep.LANDING);
    }, 1500);
  };

  const handleLoginFace = async (base64: string) => {
    if (!user) return;
    
    setIsProcessing(true);
    setAuthError(null);
    setLastResult(null);

    try {
      const result = await verifyFace(user.faceData, base64);
      setLastResult(result);
      
      if (result.match) {
        setTimeout(() => setStep(AuthStep.DASHBOARD), 800);
      } else {
        setAuthError(`Verification Error: ${result.reasoning}`);
      }
    } catch (err: any) {
      setAuthError(err.message || "Face recognition service error");
    } finally {
      setIsProcessing(false);
    }
  };

  const saveItem = () => {
    if (!user || !entryTitle.trim() || !entryContent.trim()) return;

    const newItem: StorageItem = {
      id: crypto.randomUUID(),
      title: entryTitle,
      content: entryContent,
      type: entryType,
      createdAt: Date.now()
    };

    setUser({
      ...user,
      storage: [newItem, ...user.storage]
    });

    setEntryTitle('');
    setEntryContent('');
    setIsAddingEntry(false);
  };

  const deleteItem = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (!user || !confirm("Permanently destroy this encrypted file?")) return;
    setUser({
      ...user,
      storage: user.storage.filter(item => item.id !== id)
    });
  };

  const openViewer = (item: StorageItem) => {
    setViewingItem(item);
    setStep(AuthStep.VIEWER);
  };

  const logout = () => {
    setStep(AuthStep.LANDING);
    setViewingItem(null);
  };

  const resetSystem = () => {
    if (confirm("DANGER: Wiping the system will permanently delete your biometric profile and ALL stored web pages. This cannot be undone. Proceed?")) {
      localStorage.removeItem('facevault_user_data');
      setUser(null);
      setStep(AuthStep.LANDING);
    }
  };

  // UI Components
  const LandingView = () => (
    <div className="flex flex-col items-center justify-center min-h-[75vh] text-center px-6">
      <div className="mb-10 relative">
        <div className="w-32 h-32 bg-blue-600/10 rounded-[2.5rem] flex items-center justify-center border border-blue-500/30 animate-pulse">
           <i className="fas fa-fingerprint text-6xl text-blue-500"></i>
        </div>
        <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-emerald-500 rounded-full border-4 border-gray-900 flex items-center justify-center text-[10px] text-white">
          <i className="fas fa-check"></i>
        </div>
      </div>
      
      <h1 className="text-7xl font-black mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white via-blue-400 to-indigo-600 tracking-tighter">
        FACEVAULT <span className="text-blue-500 italic">OS</span>
      </h1>
      
      <p className="text-gray-400 text-xl max-w-xl mb-12 font-medium leading-relaxed">
        Your high-security, offline-first personal web portal. Access your private web pages with a glance.
      </p>

      {!user ? (
        <button
          onClick={() => setStep(AuthStep.REGISTER_NAME)}
          className="group relative px-12 py-5 font-black text-white transition-all duration-300 bg-blue-600 rounded-2xl hover:bg-blue-500 shadow-2xl shadow-blue-500/20 active:scale-95"
        >
          Initialize Biometric Core
          <i className="fas fa-plus-circle ml-3 group-hover:rotate-90 transition-transform"></i>
        </button>
      ) : (
        <div className="flex flex-col gap-6 items-center">
          <button
            onClick={() => setStep(AuthStep.LOGIN_FACE)}
            className="group px-16 py-6 font-black text-white text-lg transition-all duration-300 bg-emerald-600 rounded-2xl hover:bg-emerald-500 shadow-2xl shadow-emerald-500/30 active:scale-95"
          >
            Authenticate to Unlock
            <i className="fas fa-lock-open ml-4 group-hover:-translate-y-1 transition-transform"></i>
          </button>
          
          <div className="mt-12 p-5 bg-gray-800/40 backdrop-blur-2xl rounded-3xl border border-gray-700/50 flex items-center gap-6 group">
            <div className="relative overflow-hidden rounded-2xl w-16 h-16">
              <img src={user.faceData} className="w-full h-full object-cover grayscale opacity-50 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-500" alt="Identity" />
              <div className="absolute inset-0 border-2 border-blue-500/30 rounded-2xl"></div>
            </div>
            <div className="text-left">
              <p className="text-[10px] text-blue-400 uppercase tracking-[0.3em] font-black mb-1">Encrypted Profile</p>
              <p className="font-bold text-2xl tracking-tight text-gray-200">{user.name}</p>
            </div>
            <button 
                onClick={resetSystem}
                className="ml-8 p-3 text-gray-600 hover:text-red-500 hover:bg-red-500/10 rounded-xl transition-all"
                title="Wipe Local Data"
            >
                <i className="fas fa-trash-can"></i>
            </button>
          </div>
        </div>
      )}
    </div>
  );

  const DashboardView = () => (
    <div className="max-w-6xl mx-auto px-6 py-10 animate-fade-in">
      <div className="flex flex-col md:flex-row items-center justify-between mb-12 gap-8 bg-gray-800/20 p-8 rounded-[3rem] border border-gray-700/30 backdrop-blur-3xl shadow-inner">
        <div className="flex items-center gap-6">
          <div className="relative">
            <img src={user?.faceData} className="w-20 h-20 rounded-2xl object-cover border-4 border-emerald-500/40 shadow-2xl" alt="Identity" />
            <div className="absolute -bottom-2 -right-2 w-6 h-6 bg-emerald-500 rounded-full border-2 border-gray-900 flex items-center justify-center text-[8px]"><i className="fas fa-check"></i></div>
          </div>
          <div>
            <h2 className="text-4xl font-black text-white tracking-tight">System Access Granted</h2>
            <p className="text-emerald-400 text-sm font-bold flex items-center gap-2 mt-1">
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
              Identity Match Verified ({((lastResult?.confidence || 0.99) * 100).toFixed(1)}%)
            </p>
          </div>
        </div>
        <button 
          onClick={logout}
          className="px-8 py-4 bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white border border-red-500/20 rounded-2xl font-black transition-all flex items-center gap-3 active:scale-95"
        >
          <i className="fas fa-power-off"></i> Lock Vault
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Navigation / Actions */}
        <div className="lg:col-span-3 space-y-6">
           <div className="bg-gray-800/40 rounded-3xl p-6 border border-gray-700/50">
              <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-6">File Operations</p>
              <button 
                onClick={() => { setIsAddingEntry(true); setEntryType('page'); }}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white p-4 rounded-2xl font-black text-sm flex items-center justify-center gap-3 transition-all mb-4 shadow-xl shadow-blue-500/20"
              >
                <i className="fas fa-code"></i> New Web Page
              </button>
              <button 
                onClick={() => { setIsAddingEntry(true); setEntryType('note'); }}
                className="w-full bg-gray-700 hover:bg-gray-600 text-white p-4 rounded-2xl font-black text-sm flex items-center justify-center gap-3 transition-all"
              >
                <i className="fas fa-file-lines"></i> New Secret Note
              </button>
           </div>
           
           <div className="bg-blue-600/5 rounded-3xl p-6 border border-blue-500/10">
              <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-4">Neural Log</p>
              <p className="text-xs text-gray-500 italic leading-relaxed">
                "{lastResult?.reasoning || "Authentication successful based on high-confidence facial parity."}"
              </p>
           </div>
        </div>

        {/* File Explorer */}
        <div className="lg:col-span-9 space-y-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-2xl font-black flex items-center gap-4">
              <i className="fas fa-server text-blue-500"></i>
              Local Storage <span className="text-gray-700">/</span> Root
            </h3>
            <span className="text-xs font-bold text-gray-500 bg-gray-800 px-3 py-1 rounded-full border border-gray-700">
              {user?.storage.length} Assets
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {user?.storage.length === 0 ? (
              <div className="col-span-full py-32 text-center bg-gray-800/10 rounded-[3rem] border-4 border-dashed border-gray-700/40">
                <i className="fas fa-inbox text-5xl text-gray-700 mb-4 block"></i>
                <p className="text-gray-500 font-bold text-xl uppercase tracking-tighter">Vault is Empty</p>
                <p className="text-gray-600 text-sm mt-2">Create your first encrypted asset to begin.</p>
              </div>
            ) : (
              user?.storage.map(item => (
                <div 
                  key={item.id} 
                  onClick={() => openViewer(item)}
                  className="bg-gray-800/30 rounded-3xl p-6 border border-gray-700/50 hover:border-blue-500/50 hover:bg-gray-800/60 transition-all group cursor-pointer relative overflow-hidden"
                >
                   <div className="flex justify-between items-start mb-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl transition-colors ${item.type === 'page' ? 'bg-blue-600/10 text-blue-500 group-hover:bg-blue-500 group-hover:text-white' : 'bg-amber-600/10 text-amber-500 group-hover:bg-amber-500 group-hover:text-white'}`}>
                        <i className={`fas ${item.type === 'page' ? 'fa-globe' : 'fa-file-shield'}`}></i>
                      </div>
                      <button 
                        onClick={(e) => deleteItem(e, item.id)}
                        className="p-2 text-gray-600 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <i className="fas fa-trash"></i>
                      </button>
                   </div>
                   <h4 className="font-black text-lg text-white mb-1 truncate">{item.title}</h4>
                   <p className="text-[10px] text-gray-500 font-black uppercase tracking-widest">
                     {item.type === 'page' ? 'HTML Web Portal' : 'Secure Text Document'}
                   </p>
                   <div className="mt-4 pt-4 border-t border-gray-700/50 flex justify-between items-center text-[9px] font-black text-gray-600 uppercase tracking-tighter">
                      <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                      <span>SECURE STORE</span>
                   </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Entry Modal */}
      {isAddingEntry && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center px-6 backdrop-blur-3xl bg-black/60 animate-fade-in">
           <div className="bg-gray-900 w-full max-w-4xl rounded-[2.5rem] border-2 border-blue-500/30 overflow-hidden shadow-[0_0_100px_rgba(37,99,235,0.2)]">
              <div className="p-8 border-b border-gray-800 flex justify-between items-center">
                <h3 className="text-2xl font-black flex items-center gap-4">
                  <i className={`fas ${entryType === 'page' ? 'fa-code' : 'fa-file-lines'} text-blue-500`}></i>
                  New {entryType === 'page' ? 'Personal Web Page' : 'Secure Note'}
                </h3>
                <button onClick={() => setIsAddingEntry(false)} className="text-gray-500 hover:text-white transition-colors">
                  <i className="fas fa-times text-2xl"></i>
                </button>
              </div>
              <div className="p-8 space-y-6">
                <input 
                  type="text" 
                  placeholder="Asset Title (e.g. My Portfolio, Bank Credentials)" 
                  className="w-full bg-gray-800/50 border border-gray-700 rounded-2xl px-6 py-4 text-xl focus:outline-none focus:border-blue-500 font-bold transition-all"
                  value={entryTitle}
                  onChange={(e) => setEntryTitle(e.target.value)}
                />
                <textarea 
                  placeholder={entryType === 'page' ? "Enter full HTML code here...\n\n<style>\n  body { background: #111; color: white; }\n</style>\n<h1>Welcome!</h1>" : "Enter sensitive note content here..."}
                  className="w-full h-80 bg-gray-950 border border-gray-800 rounded-2xl px-6 py-4 font-mono text-sm leading-relaxed focus:outline-none focus:border-blue-500/50 resize-none"
                  value={entryContent}
                  onChange={(e) => setEntryContent(e.target.value)}
                />
              </div>
              <div className="p-8 bg-gray-800/30 flex gap-4">
                <button 
                  onClick={saveItem}
                  disabled={!entryTitle.trim() || !entryContent.trim()}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 disabled:bg-gray-700 disabled:opacity-50 text-white font-black py-5 rounded-2xl transition-all shadow-xl shadow-emerald-500/20 active:scale-95"
                >
                  ENCRYPT & COMMIT TO STORAGE
                </button>
                <button onClick={() => setIsAddingEntry(false)} className="px-10 bg-gray-700 hover:bg-gray-600 text-white font-bold rounded-2xl transition-all">Cancel</button>
              </div>
           </div>
        </div>
      )}
    </div>
  );

  const PageViewer = () => (
    <div className="fixed inset-0 z-[200] bg-gray-950 flex flex-col animate-fade-in">
       <header className="p-4 border-b border-gray-800 flex justify-between items-center bg-gray-900/50 backdrop-blur-xl">
          <div className="flex items-center gap-4">
             <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${viewingItem?.type === 'page' ? 'bg-blue-600/20 text-blue-500' : 'bg-amber-600/20 text-amber-500'}`}>
                <i className={`fas ${viewingItem?.type === 'page' ? 'fa-globe' : 'fa-file-shield'}`}></i>
             </div>
             <div>
                <h2 className="font-black text-lg text-white leading-none">{viewingItem?.title}</h2>
                <p className="text-[9px] text-gray-500 uppercase tracking-widest mt-1 font-bold">Secure Browser Session / Isolated Environment</p>
             </div>
          </div>
          <button 
            onClick={() => { setStep(AuthStep.DASHBOARD); setViewingItem(null); }}
            className="px-6 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-xl font-bold transition-all flex items-center gap-2"
          >
            <i className="fas fa-arrow-left"></i> Exit Viewer
          </button>
       </header>
       <main className="flex-1 overflow-auto bg-gray-950">
          {viewingItem?.type === 'page' ? (
            <iframe 
              srcDoc={viewingItem.content} 
              className="w-full h-full border-none bg-white" 
              sandbox="allow-scripts"
              title="Secure Page Viewer"
            />
          ) : (
            <div className="max-w-4xl mx-auto py-16 px-8">
               <div className="bg-gray-900 p-12 rounded-[3rem] border border-gray-800 shadow-2xl">
                  <pre className="text-gray-300 font-mono text-lg whitespace-pre-wrap leading-relaxed">{viewingItem?.content}</pre>
               </div>
            </div>
          )}
       </main>
    </div>
  );

  return (
    <div className="min-h-screen font-sans selection:bg-blue-500/30">
      <header className="p-6 flex justify-between items-center border-b border-gray-800 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-4 cursor-pointer" onClick={() => setStep(AuthStep.LANDING)}>
          <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl flex items-center justify-center shadow-2xl shadow-blue-600/20 border border-blue-500/30">
            <i className="fas fa-shield-halved text-2xl text-white"></i>
          </div>
          <div>
            <span className="text-2xl font-black tracking-tighter text-white">FaceVault <span className="text-blue-500">AI</span></span>
            <p className="text-[8px] text-gray-500 font-bold uppercase tracking-[0.2em]">Neural Biometric Secure OS</p>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-3">
          <div className="text-[10px] font-black text-gray-400 bg-gray-800 px-4 py-2 rounded-full border border-gray-700 uppercase tracking-widest">
            {user ? 'Authenticated Zone' : 'Restricted Access'}
          </div>
        </div>
      </header>

      <main>
        {authError && (
          <div className="max-w-md mx-auto mt-8 p-5 bg-red-500/10 border border-red-500/20 text-red-400 rounded-3xl flex items-center gap-4 animate-shake">
            <i className="fas fa-triangle-exclamation text-xl"></i>
            <p className="text-sm font-black uppercase tracking-tight">{authError}</p>
          </div>
        )}

        {step === AuthStep.LANDING && <LandingView />}
        
        {step === AuthStep.REGISTER_NAME && (
          <div className="flex flex-col items-center justify-center min-h-[60vh] max-w-md mx-auto px-6 animate-fade-in">
            <h2 className="text-4xl font-black mb-8 tracking-tighter">Identity Initialization</h2>
            <div className="w-full group">
              <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2 ml-4">Full Legal Name</p>
              <input
                type="text"
                value={tempName}
                onChange={(e) => setTempName(e.target.value)}
                placeholder="Enter Identity Name"
                className="w-full bg-gray-800 border-2 border-gray-700 rounded-3xl px-8 py-5 text-xl focus:outline-none focus:border-blue-500 transition-all font-bold placeholder:text-gray-600"
                autoFocus
              />
            </div>
            <button
              disabled={!tempName.trim()}
              onClick={() => setStep(AuthStep.REGISTER_FACE)}
              className={`mt-10 w-full py-5 rounded-3xl font-black text-xl transition-all shadow-2xl ${
                tempName.trim() ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-500/20' : 'bg-gray-800 text-gray-600 cursor-not-allowed'
              }`}
            >
              Continue to Biometrics
            </button>
            <button onClick={() => setStep(AuthStep.LANDING)} className="mt-6 text-gray-500 hover:text-white transition-colors font-bold text-sm">Cancel System Init</button>
          </div>
        )}

        {step === AuthStep.REGISTER_FACE && (
          <div className="animate-fade-in max-w-2xl mx-auto py-10 px-6">
            <h2 className="text-4xl font-black text-center mb-2 tracking-tighter">Biometric Mapping</h2>
            <p className="text-gray-500 text-center mb-12 font-medium">Please look directly into the scanner, {tempName}.</p>
            <Camera 
              label="Initialize Biometric Baseline" 
              isProcessing={isProcessing} 
              onCapture={handleRegisterFace} 
            />
            <button onClick={() => setStep(AuthStep.REGISTER_NAME)} className="block mx-auto mt-10 text-gray-500 hover:text-white font-bold">Restart Profile</button>
          </div>
        )}

        {step === AuthStep.LOGIN_FACE && (
          <div className="animate-fade-in max-w-2xl mx-auto py-10 px-6">
            <h2 className="text-4xl font-black text-center mb-2 tracking-tighter">Verification Scan</h2>
            <p className="text-gray-500 text-center mb-12 font-medium">Validating biometric signature for <span className="text-blue-400">{user?.name}</span></p>
            <Camera 
              label="Initiate Scan" 
              isProcessing={isProcessing} 
              onCapture={handleLoginFace} 
            />
            <button onClick={() => setStep(AuthStep.LANDING)} className="block mx-auto mt-10 text-gray-500 hover:text-white font-bold">Abort Auth</button>
          </div>
        )}

        {step === AuthStep.DASHBOARD && <DashboardView />}
        {step === AuthStep.VIEWER && <PageViewer />}
      </main>

      <footer className="fixed bottom-0 w-full p-6 text-center text-[9px] text-gray-700 pointer-events-none font-black tracking-[0.4em] uppercase">
        Encrypted Local Persistence • Gemini Visual Engine • Privacy Mode Active
      </footer>
    </div>
  );
};

export default App;
